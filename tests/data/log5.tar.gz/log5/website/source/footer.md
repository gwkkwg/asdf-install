<div id="footer">
{include navigation.md}

### Copyright (c) 2007 Gary Warren King (gwking@metabang.com) 

Log5 has an [MIT style][mit-license] license

<br>
<span id='other-software'>[Other Software][metabang-software]</span>
<span id="timestamp">Last updated {today} at {now}</span>
</div>