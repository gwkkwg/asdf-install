<div id="footer">
{include navigation.md}

### Copyright (c) 2007 Gary Warren King (gwking@metabang.com) 

Log5 has an [MIT style][mit-license] license

<br>
<div id="timestamp">Last updated {today} at {now}</div>
</div>